/*
 * LedCfg.h
 *
 * Created: 7/23/2022 8:14:05 PM
 *  Author: Electric_Water_Heater_Team
 */ 


#ifndef LEDCFG_H_
#define LEDCFG_H_

/********* Define the Pins of LEDs ********/
#define LED_PORT_DIR DDRB
#define LED_PORT PORTB
#define LED_PIN 0



#endif /* LEDCFG_H_ */