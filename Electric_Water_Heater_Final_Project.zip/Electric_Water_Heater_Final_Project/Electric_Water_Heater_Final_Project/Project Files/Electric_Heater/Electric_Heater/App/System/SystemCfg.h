/*
 * SystemCfg.h
 *
 * Created: 7/23/2022 9:09:13 PM
 *  Author: Electric_Water_Heater_Team
 */ 


#ifndef SYSTEMCFG_H_
#define SYSTEMCFG_H_

/*****************************************_DEFINE_SYSTEM_PARAMETERS_*************************************************/
#define MARGIN_TEMP 5
#define MAX_TEMP 75
#define MIN_TEMP 35
#define INIT_DESIRED_TEMP 50
#define NUM_OF_TEMP_MEASURES 10



#endif /* SYSTEMCFG_H_ */